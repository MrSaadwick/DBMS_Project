EXEC CheckRoomAvailability 
    @check_in_date = '2025-12-01',
    @check_out_date = '2025-12-05',
    @room_type_id = 1,
    @adults_count = 2,
    @children_count = 1;