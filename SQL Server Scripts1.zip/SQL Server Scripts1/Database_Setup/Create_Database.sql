-- Create the database
CREATE DATABASE HotelBookingSystem;
GO

-- Use the database
USE HotelBookingSystem;
GO
